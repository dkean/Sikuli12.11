*** SikuliX-1.0MacBeta ***
--------------------------

Be aware: 
- still work in progress - might contain bugs
- not everything is tested
- not everything is implemented nor documented
- RaiMan is offline until Dec 20th and does not react on any complains


*** Installation
unzip to any location you like


*** Usage ONLY from command line
- go to the installation directory
- use either sikuli-ide (starts the IDE) or sikli-script (to run scripts) this way:
. sikuli-ide
. sikuli-script

to run the command files

- you might make them executable using chmod
- if you want to run the command files from any other directory, you have to use
export SIKULI_HOME=<absolute path to installation folder>
on the commandline before using the commands